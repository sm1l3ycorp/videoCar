import React from 'react';
import './App.css';
import Camera from './Components/Camera';
import Controls from './Components/Controls';

function App() {
  return (
    <div className="app">
      <Camera />
      <Controls />
    </div>
  );
}

export default App;
