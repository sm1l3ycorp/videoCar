import React from 'react';
import Styles from './Camera.module.css';
import Iframe from 'react-iframe'

const Camera = () => {
    return (
        <div className={Styles.video}>
            <div>
                <Iframe url="http://pi2:8081/"
                    width="640px"
                    height="480px"
                    id="myId"
                    // className="myClassname"
                    display="initial"
                    position="relative"/>
            </div>
        </div>
    )
}

export default Camera;
