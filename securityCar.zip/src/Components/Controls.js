import React from 'react';
import Styles from './Controls.module.css';
import Button from '@material-ui/core/Button';
import API from '../Utils/API';

const move = (direction) => {
    API.getData(direction);
    console.log(direction);
}

const Controls = () => {
    return (
        <div className={Styles.main}>
            <div>
            <Button onClick={() => move(`forward`)}>Forward</Button>
            <Button onClick={() => move(`reverse`)}>Reverse</Button>
            <Button onClick={() => move(`stop`)}>Stop</Button>   
            <Button onClick={() => move(`left`)}>Left</Button>   
            <Button onClick={() => move(`right`)}>Right</Button>
            </div>          
        </div>
    )
}

export default Controls;
