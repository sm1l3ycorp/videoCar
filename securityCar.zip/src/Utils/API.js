import axios from 'axios';

const server = 'http://pi2:5000/car/move/';

export const getData = (direction) => {
    try {
    axios.get(`${server}${direction}`)
    .then(function (response) {
    // handle success
    console.log(response);
    })
    .catch(function (error) {
    // handle error
    console.log(error);
    })
    .then(function () {
    // always executed
    });
} catch (err) {
    console.log(err);
}
}

export default getData.getData = getData;